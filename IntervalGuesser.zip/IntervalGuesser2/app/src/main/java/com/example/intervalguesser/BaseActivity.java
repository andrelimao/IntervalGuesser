package com.example.intervalguesser;

import android.app.Activity;
import android.os.Bundle;

import java.lang.Override;
abstract class BaseActivity extends Activity {

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.base_activity);
        View visao = new View();
        visao.setBackgroundDrawable(getResources().getDrawable(android.R.drawable.backgroundapp));

    }
}
